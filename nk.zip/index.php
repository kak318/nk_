<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="style.css">
    <title>NK</title>
  </head>
  <body>
    <?php
      $user = $_POST['login'];
      if ($user == "") {
        echo '<a href="login.php"><button class="btn login">LOGIN</button></a><div class="title">NK</div>';
      } else {
        echo '<button class="btn login">'.$user.'</button><div class="title">NK</div>';
      }
      session_start();
      $_SESSION['foo'] = $user;
    ?>
  </body>
</html>
