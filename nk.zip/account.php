<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="style.css">
    <title>NK</title>
  </head>
  <body>
    <div class="title">My Account</div>
    <?php
      $user = $_POST['foo'];
      echo $user;
    ?>
  </body>
</html>
